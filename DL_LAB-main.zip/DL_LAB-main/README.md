Experiment 1: MNIST using NumPy
In this experiment, we implement a neural network to classify the MNIST dataset using only NumPy, focusing on the fundamentals of training a neural network without relying on high-level libraries like TensorFlow or PyTorch.

Experiment 2: Analyze Non-Linear Dataset using scikit-learn
This experiment explores analyzing and modeling a non-linear dataset using the scikit-learn library. It includes preprocessing, feature engineering, and applying various machine learning models to solve the classification problem.

Experiment 3: CNN Implementation
The objective of this lab is to implement Convolutional Neural Networks (CNNs) to classify
images in the Cats vs. Dogs dataset and the CIFAR-10 dataset. 
configurations by experimenting with:
3 Activation Functions
3 Weight Initialization Techniques
3 Optimizers
